// export const booksSearchableFields = ['title', 'author', 'genre', 'price']
