Team Name: TEAM JOY BANGLA
institution Name: Hamdard University Bangladesh

Members 1: 
Md Habibur Rahman
habibrahman2580@gmail.com
institutions Email: 315232060@hamdarduniversity.edu.bd

Members 2: 
Kazi Maksud ul Mahin
kazimahin80@gmail.com
institutions Email: 315232045@hamdarduniversity.edu.bd


Members 3: 
Amimul Haque
amimul.hq@gmail.com
institutions Email: 315232054@hamdarduniversity.edu.bd